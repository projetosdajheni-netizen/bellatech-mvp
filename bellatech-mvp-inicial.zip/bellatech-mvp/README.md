# BellaTech — Interview Coach (MVP)

Protótipo de preparação para entrevistas de emprego em inglês com apoio de IA, com foco inicial em mulheres LGBTQIAPN+ iniciantes no idioma.

**Estado:** estrutura inicial não publicada. O projeto ainda não possui Supabase, aprovação humana nem validação, e portanto não atende integralmente aos requisitos do projeto final.

## Arquitetura inicial
- React + Vite — interface.
- Vercel Functions (`api/generate.js`) — chamada de IA no servidor.
- Gemini 2.5 Flash Lite — conteúdo demonstrativo (sujeito aos limites gratuitos).
- Supabase — integração prevista, ainda não implementada.

## Segurança
A chave deve ficar apenas em variável de ambiente de servidor chamada `GEMINI_API_KEY`. Nunca publique a chave no GitHub, em arquivos de frontend, screenshots ou mensagens. Não ative faturamento para este MVP.

## Executar
- `npm install`
- `npm run dev` — interface em desenvolvimento.
- O endpoint `/api/generate` exige uma execução em ambiente compatível com Vercel Functions e configuração de `GEMINI_API_KEY`.

## Próximas entregas obrigatórias
1. Base de dados real consultada pelo fluxo.
2. Automação com pelo menos três execuções registradas.
3. Etapa de revisão e aprovação humana antes da entrega a participantes reais.
4. Validação em duas rodadas, 20 casos e três avaliadoras adicionais, documentação de custos e LGPD.

O formulário de pesquisa de mercado é separado deste protótipo.
